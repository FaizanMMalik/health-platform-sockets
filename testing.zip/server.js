require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const bodyParser = require('body-parser');
const { GoogleAuth } = require("google-auth-library");
const fs = require('fs');
const app = express();
const server = http.createServer(app);
const path = require('path');
const cors = require('cors'); // Import CORS module
const axios = require('axios');
const knex = require('knex');
require('dotenv').config();
const config = require('./knexfile');
const db = require('./db'); // Path to your db.js file
const { registerChatHandlers } = require('./socketHandlers/chatHandler');
const admin = require('firebase-admin');
const serviceAccount = require('./public/serviceAccountKey.json');
const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 3001}`;

// Initialize Firebase Admin SDK
admin.initializeApp({   
    credential: admin.credential.cert(serviceAccount),
});



// Initialize Firebase Admin SDK
//admin.initializeApp({
//    credential: admin.credential.cert(serviceAccount),
//});

// const db = knex(config.development);
// Load SSL certificate and key
// const options = {
//     key: fs.readFileSync('/etc/nginx/ssl/www_brightspace_health.key'),
//     cert: fs.readFileSync('/etc/nginx/ssl/www_brightspace_health.crt'),
//     ca: fs.readFileSync('/etc/nginx/ssl/www_brightspace_health.ca-bundle')
// };


// Test database connection
db.raw('show tables')
    .then(() => {
        console.log('Database connected!');
    })
    .catch((err) => {
        console.error('Error connecting to database:', err);
    });

// Middleware
app.use(cors({
    origin: '*', // Allow requests from this origin
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true, // Allow credentials if necessary
}));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files
app.use('/public/uploads', express.static(path.join(__dirname, 'public', 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

const io = socketIo(server, {
    cors: {
        origin: '*',
        methods: ['GET', 'POST', 'PUT'],
        allowedHeaders: ['Content-Type'],
        credentials: true,
    },
});
const roomsRouter = require('./routes/rooms');
const imagesRouter = require('./routes/images');
const VideosRouter = require('./routes/videoimages');
const ImageArray = require('./routes/ImageArray');

// Body parser middleware

app.use(cors({
    origin: '*', // Allow requests from this origin
    methods: ['GET', 'POST', 'PUT'],
    allowedHeaders: ['Content-Type'],
    credentials: true
}));

app.use(bodyParser.json());

app.use('/public/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

app.use(bodyParser.urlencoded({ extended: true }));


const onlineUsers = new Set();


io.on('connection', (socket) => {

    registerChatHandlers(io, socket, db, sendPushNotificationMessage, baseUrl);

    socket.on('chat-status', async (data) => {
        const {
            messageId,
            status,       // SENT | UNREAD | READ
            fromUserId,   // sender
            toUserId      // receiver
        } = data;

        try {

            /* ================= DB UPDATE (OPTIONAL) ================= */
            if (status === 'READ') {
                await db('chat')
                    .where('id', messageId)
                    .update({ is_read: 1 });
            }

            /* ================= EMIT LOGIC =================
               SENT     → sender ko
               UNREAD   → sender ko
               READ     → sender ko
            ================================================= */

            await db('chat')
                .where('id', messageId)
                .update({ status: status });

            io.emit(`chat-status-${fromUserId}`, {
                messageId,
                status,
                fromUserId,
                toUserId
            });
             io.emit(`chat-status-${toUserId}`, {
                messageId,
                status,
                fromUserId,
                toUserId
            });

        } catch (e) {
            db('logs_sockets').insert({
                socket_name: `chat-status-${fromUserId}`,
                error: e.message,
                payload: JSON.stringify(data)
            });
        }
    });

    app.post('/api/fcm-send-logout', async (req, res) => {
        const { user_id, activeid, token } = req.body;
        try {
            if (user_id) {
                const userTokens = await db('fcmtoken').where('user_id', user_id);

                if (userTokens && userTokens.length > 0) {
                    const tokensToSend = userTokens.filter(t => t.token && t.token !== token);

                    if (tokensToSend.length > 0) {
                        const messages = tokensToSend.map(tokenObj => ({
                            token: tokenObj.token,
                            data: {
                                ACTION: "LOGOUT",
                            }
                        }));
                        await sendPushNotificationMessage(messages);
                    }

                    if (token && token.trim() !== "") {
                        await db('fcmtoken').where('user_id', user_id).update({ token });
                        await db('profile').where('user_id', user_id).update({ token });
                    }
                } else {
                    if (token && token.trim() !== "") {
                        const userTokenExist = await db('fcmtoken')
                            .where({ user_id, token })
                            .first();

                        if (!userTokenExist) {
                            await db('fcmtoken').insert({ user_id, token });
                        }
                    }
                }
            }

            return res.status(200).json({ status: true, message: 'success' });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ status: false, message: 'Internal server error' });
        }
    });








    socket.on('offer', (data) => {
        const { targetUserId, offerData, from, iceCandidates } = data;
        try {
            io.emit(`offer-${targetUserId}`, { "offerData": offerData, "from": from, "targetUserId": targetUserId, "iceCandidates": iceCandidates });
        } catch (e) {
            db('logs_sockets').insert({
                socket_name: `offer-${targetUserId}`,
                error: e.message, // Access the error message here
            });
        }
    });

    socket.on('make-offer', (data) => {
        const { targetUserId, from } = data;
        try {
            io.emit(`make-offer-${targetUserId}`, { "from": from, "targetUserId": targetUserId });
        } catch (e) {
            db('logs_sockets').insert({
                socket_name: `make-offer-${targetUserId}`,
                error: e,
            });
        }
    });;

    socket.on('offer-acknowledgment', (data) => {
        const { from, targetUserId, offerData } = data;
        try {
            io.emit(`offer-acknowledgment-${targetUserId}`, { "offer": offerData, "from": from, "targetUserId": targetUserId });
        } catch (e) {
            db('logs_sockets').insert({
                socket_name: `offer-acknowledgment-${targetUserId}`,
                error: e,
            });
        }

    });

    socket.on('answer', (data) => {
        const { targetUserId, answerData, from } = data;
        try {
            io.emit(`answer-${targetUserId}`, { "answerData": answerData, "from": from, "targetUserId": targetUserId });
        } catch (e) {
            db('logs_sockets').insert({
                socket_name: `answer-${targetUserId}`,
                error: e,
            });
        }
    });

    socket.on('ice-candidate', (data) => {
        const { from, targetUserId, iceCandidateData } = data;
        try {
            io.emit(`ice-candidate-${targetUserId}`, { iceCandidateData, from, targetUserId });
        } catch (e) {
            db('logs_sockets').insert({
                socket_name: `ice-candidate-${targetUserId}`,
                error: e,
            });
        }
    });
    socket.on('test', (data) => {
        console.log('====================================');
        console.log(data);
        console.log('====================================');
    });

    socket.on('message', async (data, ackCallback) => {


        try {
            const { from, to, message, messageType, attachment, iscaregiver, metadata } = data;


            const localDate = new Date(); // Assume this is a local date and time
            const utcDateString = localDate.toISOString();

            const [fromU, toU] = await Promise.all([
                db('profile').where('user_id', from).first(),
                db('profile').where('user_id', to).first()
            ]);


            if (!fromU || !toU) {
                const errorMsg = !fromU ? 'From User not found' : 'To User not found';
                io.emit('notification-error', { status: false, message: errorMsg });
                return;
            }


            const chatNew = {
                from_id: from,
                to_id: to,
                message,
                created_time: utcDateString,
                attachment: attachment ? attachment[0] : null,
                messageType: messageType,
                iscaregiver: iscaregiver,
                type: messageType,
                metadata: metadata ? JSON.stringify(metadata) : "",
                is_read: "1",
                is_chat: "1",
            };

            [insertedMessage] = await db('chat').insert(chatNew);

            const id = insertedMessage;
            console.log(id);
            console.log(insertedMessage);
            ackCallback("{'msgId':" + id + "}");

            const userTokens = await db('fcmtoken').where('user_id', to).select('token');
            console.log(userTokens);


            // return
            // Extract just the tokens into an array
            const data1 = {
                data: {
                    fromUser: from,
                    toUser: to,
                    ACTION: "MESSAGE",
                    insertedMessage: parseInt(id),
                    messageType: messageType,
                    attachment: attachment && attachment.length > 0 ? attachment : null, // Allow null if no attachment
                    message: message,
                    metadata: JSON.stringify(metadata),
                }
            };

            // Prepare the token list and map the messages
            const tokenList = userTokens.map(tokenObject => tokenObject.token);
            const messages = tokenList.map(token => ({
                token,
                data: {
                    DocotorName: JSON.stringify(fromU.first_name + " " + fromU.last_name),
                    fromUser: JSON.stringify(data1?.data?.fromUser),
                    toUser: JSON.stringify(data1?.data.toUser),
                    ACTION: JSON.stringify(data1?.data.ACTION),
                    insertedMessage: JSON.stringify(data1?.data?.insertedMessage),  // FCM requires strings for numeric values
                    messageType: JSON.stringify(data1?.data?.messageType),
                    attachment: JSON.stringify(data1?.data?.attachment) ? JSON.stringify(data1.data.attachment) : null, // Serialize attachment if not null
                    message: JSON.stringify(data1.data.message),
                    metadata: JSON.stringify(metadata),
                }
            }));

            console.log(tokenList);

            // Send the messages
            await sendPushNotificationMessage(messages);

            io.emit('notification-success', {
                message, from: JSON.stringify(fromU), to: JSON.stringify(toU), "ACTION": "MESSAGE", insertedMessage: parseInt(id), metadata: metadata, messageType: messageType, attachment: attachment,
            });

            io.emit(`offer-acknowledgment-${to}`, { insertedMessage: parseInt(insertedMessage) });

            io.emit('pushnotification', {
                data1: data1.data // Convert to a number

            });
            io.emit(`receive-message-${to}`, {
                message, from: JSON.stringify(fromU), to: JSON.stringify(toU), "ACTION": "MESSAGE", insertedMessage: parseInt(id), metadata: metadata, messageType: messageType, attachment: attachment,
            });


        } catch (error) {
            console.error('Error:', error);
            io.emit('notification-error', { status: false, message: 'Error processing request' });
        }
    });

    socket.on('call-status', (data) => {
        const { from, targetUserId, call_status } = data;


        try {
            io.emit(`call-status-${targetUserId}`, { call_status, from, targetUserId });
        } catch (e) {
            db('logs_sockets').insert({
                socket_name: `call-status-${targetUserId}`,
                error: e,
            });
        }
    });

    socket.on('call-offer', async (data, ackCallback) => {
        try {
            const { doc_id, patient_id, customData, staff_id } = data;

            const customData1 = JSON.parse(customData);
            console.log(customData1, "::::::::");

            const [fromU, toU] = await Promise.all([
                db('profile')
                    .where('user_id', customData1.fromUser)
                    .select(db.raw("CONCAT(first_name, ' ', last_name) as name"), 'id', 'user_id')
                    .first(),
                db('profile')
                    .where('user_id', customData1.toUser)
                    .select(db.raw("CONCAT(first_name, ' ', last_name) as name"), 'id', 'user_id')
                    .first()
            ]);

            console.log(fromU);
            console.log(toU);

            const [patintData, doctorData] = await Promise.all([
                db('profile')
                    .where('user_id', patient_id)
                    .select(db.raw("CONCAT(first_name, ' ', last_name) as name"), 'id', 'user_id')
                    .first(),
                db('profile')
                    .where('user_id', doc_id)
                    .select(db.raw("CONCAT(first_name, ' ', last_name) as name"), 'id', 'user_id')
                    .first()
            ]);

            console.log(patintData);
            console.log(doctorData);

            const userTokens = await db('fcmtoken').where('user_id', customData1?.toUser).select('token');
            console.log(userTokens);

            const data1 = {
                patienr: patintData,
                doctor: doctorData,
                staff_id: staff_id ?? "",
                doc_id: doc_id,
                patient_id: patient_id,
                customData: customData1,
                ACTION: "CALL",
            };


            io.emit('notification-success', {
                data: data1, from: customData1?.fromUser, to: customData1?.toUser, "ACTION": "CALL",
            });

            io.emit('pushnotification', { data: data1 });

            io.emit(`call-offer-${customData1.toUser}`, { data: data1 });

            console.log(data1);

            const tokenList = userTokens.map(tokenObject => tokenObject.token);



            const messages = tokenList.map(token => ({
                token,
                data: {
                    patienr: JSON.stringify({
                        name: patintData?.name,
                        user_id: patintData?.user_id,
                    }),
                    doctor: JSON.stringify({
                        name: doctorData?.name,
                        user_id: doctorData?.user_id,
                    }),
                    doc_id: String(doc_id ?? ""),
                    staff_id: String(staff_id ?? ""),
                    patient_id: String(patient_id ?? ""),
                    customData: JSON.stringify({
                        appointment: customData1.appointment,
                        RoomID: customData1.RoomID,
                        fromUser: customData1.fromUser,
                        toUser: customData1.toUser,
                        isVideo: customData1.isVideo
                    }),
                    ACTION: "CALL",
                }
            }));


            await sendPushNotificationMessage(messages);


            ackCallback("{'call':" + "1" + "}");

            io.emit('notification-success', {
                tokenList: "called 2, ", messages,
            });


            io.emit('notification-success', {
                tokenList: "called 1, ",

            });


        } catch (error) {
            console.error('Error:', error);
            io.emit('notification-error', { status: false, message: 'Error processing request' });
        }
    });


    socket.on('camera-switch', async (data) => {
        try {
            const { doc_id, patient_id, customData, staff_id } = data;

            const customData1 = JSON.parse(customData);

            io.emit(`camera-switch-${customData1.toUser}`, { data: data });

        } catch (error) {
            console.error('Error:', error);
            io.emit('notification-error', { status: false, message: 'Error processing request' });
        }
    });


    socket.on('message-status', async (data) => {
        try {
            const { message_status, from, to, msgId } = data;


            const [fromU, toU] = await Promise.all([
                db('profile').where('user_id', from).first(),
                db('profile').where('user_id', to).first()
            ]);

            if (!fromU || !toU) {
                const errorMsg = !fromU ? 'From User not found' : 'To User not found';
                io.emit('notification-error', { status: false, message: errorMsg });
                return;
            }
            const chatNew = {
                is_read: "0",
            };
            const condition = { id: msgId };

            const data1 = {
                data: {
                    fromUser: fromU,
                    toUser: toU,
                    ACTION: "MESSAGE_STATUS",
                    is_read: message_status,
                    msgId: msgId
                },
                registration_ids: [toU.token],
            };

            const response = await axios.post('https://fcm.googleapis.com/fcm/send', data1, {
                headers: {
                    Authorization: process.env.FCM_SERVER_KEY,
                    'Content-Type': 'application/json',
                },
            });

            console.log('====================================');
            console.log(response);
            console.log('====================================');

            io.emit('notification-success', {
                message, from: fromU, to: toU, msgId: msgId, "ACTION": "MESSAGE_STATUS"
            });

            io.emit('pushnotification', {
                data1: data1 // Convert to a number

            });
            await db('chat').where(condition).update(chatNew);

            io.emit(`message-status-${to}`, { "data": data });
        } catch (e) {
            console.error(`Error updating statuses in the database: ${error}`);
        }
    });

    socket.on('userStatus', async (data) => {
        const { userId } = data;
        try {
            onlineUsers.add(socket.id);
            await db('profile').where({ user_id: userId }).update({ socket_id: socket.id });
            await db('profile').where({ user_id: userId }).update({ status: 'isActive' });
            io.emit(`userOnline-${userId}`, { isActive: true, userId: userId });

        } catch (error) {
            console.error(`Error updating statuses in the database: ${error.message}`);
        }
    });

    socket.on('userStatusCheck', async (data, ackCallback) => {
        const { userId } = data;
        try {
            onlineUsers.add(socket.id);
            const statusCheck = await db('profile').where({ user_id: userId });
            ackCallback({ statusCheck: statusCheck })  // ye wala aesay
            io.emit(`statusCheck-${userId}`, { statusCheck: statusCheck });

        } catch (error) {
            console.error(`Error updating statuses in the database: ${error.message}`);
        }
    });

    socket.on(`chat-history`, async (data) => {
        const { from, to } = data;

        try {
            // Ensure 'from' and 'to' are provided and valid
            if (!from || !to) {
                throw new Error('Invalid parameters');
            }

            // Fetch chat history from database
            const query = await db('chat AS c')
                .join('profile AS p_from', 'c.from_id', 'p_from.user_id')
                .join('profile AS p_to', 'c.to_id', 'p_to.user_id')
                .select(
                    'c.*',
                    'p_from.user_id AS from_user_id',
                    'p_from.first_name AS from_first_name',
                    'p_from.last_name AS from_last_name',
                    'p_to.user_id AS to_user_id',
                    'p_to.first_name AS to_first_name',
                    'p_to.last_name AS to_last_name'
                )
                .where(function () {
                    this.where(function () {
                        this.where('from_id', from).andWhere('to_id', to);
                    }).orWhere(function () {
                        this.where('from_id', to).andWhere('to_id', from);
                    });
                })
                .orderBy('c.id', 'desc');


            // Emit chat history to the client
            io.emit(`chat-history-${from}-${to}`, { history: query });

        } catch (error) {
            console.error('Error fetching chat history:', error); // Log error for debugging
            io.emit(`chat-history-${from}-${to}`, { message: "Error in fetching chat history", error: error.message });
        }
    });

    socket.on('chat-history-doc-pat', async (data) => {
        const { patientId, doctorId } = data;

        try {
            if (!patientId || !doctorId) {
                throw new Error('patientId and doctorId are required');
            }

            const query = await db('chat AS c')
                .join('profile AS p_from', 'p_from.user_id', 'c.from_id')
                .join('profile AS p_to', 'p_to.user_id', 'c.to_id')
                .leftJoin('profile AS p_patient', 'p_patient.user_id', 'c.patientId')
                .leftJoin('profile AS p_doctor', 'p_doctor.user_id', 'c.doctorId')
                .where('c.patientId', patientId)
                .andWhere('c.doctorId', doctorId)
                .whereNotNull('c.patientId')
                .whereNotNull('c.doctorId')
                .select(
                    'c.*',
                    'p_from.user_id AS from_user_id',
                    'p_from.first_name AS from_first_name',
                    'p_from.last_name AS from_last_name',
                    'p_to.user_id AS to_user_id',
                    'p_to.first_name AS to_first_name',
                    'p_to.last_name AS to_last_name'
                )
                .orderBy('c.id', 'desc');

            io.emit(`chat-history-doc-pat-${patientId}-${doctorId}`, { history: query });

        } catch (error) {
            console.error('Error fetching chat history:', error);
            io.emit(`chat-history-doc-pat-${patientId}-${doctorId}`, { message: "Error in fetching chat history", error: error.message });
        }
    });

    socket.on('room-details', async (data) => {
        try {
            const { roomID } = data;

            const meetingsUsers = await db('meeting')
                .join('profile', 'meeting.user_id', 'profile.user_id')
                .where({ 'meeting.room_id': roomID })
                .select('*'); // select all fields from both tables

            io.emit(`room-details-${roomID}`, {
                data,
                meetingsUsers: meetingsUsers,
                ACTION: "JOIN",
            });

        } catch (error) {
            console.error(`Error in room-join for room ${data.roomID}:`, error);

            socket.emit(`room-join-detail-error-${data.roomID}`, {
                error: error.message || 'Something went wrong while joining the room.',
            });
        }
    });

    socket.on('room-join', async (data) => {
        try {
            const { roomID, userId, agoraUid } = data;

            let meeting = await db('meeting')
                .where({ user_id: userId, room_id: roomID, agoraUid: agoraUid })
                .first();

            if (!meeting) {
                await db('meeting').insert({
                    user_id: userId,
                    room_id: roomID,
                    agoraUid: agoraUid,
                });
            }

            const meetingsUsers = await db('meeting')
                .join('profile', 'meeting.user_id', 'profile.user_id')
                .where({ 'meeting.room_id': roomID })
                // .where({ 'meeting.agoraUid': agoraUid })
                .select('*'); // select all fields from both tables

            io.emit(`room-join-${roomID}`, {
                data,
                meetingsUsers: meetingsUsers,
                ACTION: "JOIN",
            });

        } catch (error) {
            console.error(`Error in room-join for room ${data.roomID}:`, error);

            // Optionally notify the client that something went wrong
            socket.emit(`room-join-error-inf`, {
                error: error.message || 'Something went wrong while joining the room.',
            });
        }
    });

    socket.on('room-join-user', async (data) => {
        try {
            const { agoraUid } = data;

            const meetingsUsers = await db('meeting')
                .join('profile', 'meeting.user_id', 'profile.user_id')
                .where({ 'meeting.agoraUid': agoraUid })
                .select('*'); // select all fields from both tables

            io.emit(`room-join-user-${agoraUid}`, {
                meetingsUsers: meetingsUsers,
                ACTION: "JOIN",
            });

        } catch (error) {
            console.error(`Error room-join-user ${agoraUid}:`, error);

            // Optionally notify the client that something went wrong
            socket.emit(`room-join-error}`, {
                error: error.message || 'Something went wrong while joining the room.',
            });
        }
    });


    socket.on(`disconnect`, async () => {
        onlineUsers.delete(socket.id);
        const profileData = await db('profile').where({ socket_id: socket.id }).first();

        if (profileData && profileData.user_id) {
            const userId = profileData.user_id;

            await db('profile').where({ socket_id: socket.id }).update({ status: 'isDeactive' });
            const data = {
                data: {
                    "userId": userId,
                    ACTION: "DISCONNECTED",
                },
                registration_ids: [profileData.token],
            };

            axios.post('https://fcm.googleapis.com/fcm/send', data, {
                headers: {
                    Authorization: process.env.FCM_SERVER_KEY,
                    'Content-Type': 'application/json',
                },
            }).then((response) => {
                console.log('====================================');
                console.log(response);
                console.log('====================================');
                io.emit(`userOffline-${userId}`, { isActive: false, userId: userId });

                io.emit('notification-success', {
                    userId: userId, "ACTION": "MESSAGE_STATUS"
                });

                io.emit('pushnotification', {
                    data1: data // Convert to a number

                });
            }).catch((error) => {
                console.log('====================================');
                console.log(error);
                console.log('====================================');
                // return res.status(500).json({ status: false, data: error, message: 'To User not found' });
            });
        } else {
            console.log('No user found with the provided socket_id');
        }
    });

    socket.on('test', (data) => {

        io.emit('test-success', {
            data: data,
        });
    });

});

async function sendUserNotification({
    targetUserId,
    message,
    type,
    payload = {},
    from = null,
    io,
    socket = null,
    db
}) {
    /* ================= SOCKET EMIT ================= */
    io.emit(`user-notification-${targetUserId}`, {
        message,
        type,
        payload,
        from,
        time: new Date().toISOString()
    });

    /* ================= PUSH NOTIFICATION ================= */
    const userTokens = await db('fcmtoken')
        .where('user_id', targetUserId)
        .select('token');

    if (userTokens && userTokens.length > 0) {
        const messages = userTokens.map(t => ({
            token: t.token,
            data: {
                ACTION: 'NOTIFICATION',
                type: JSON.stringify(type),
                message: JSON.stringify(message),
                from: JSON.stringify(from),
                payload: JSON.stringify(payload),
            }
        }));

        await sendPushNotificationMessage(messages);
    }

    /* ================= ACK (if socket) ================= */
    if (socket) {
        socket.emit('user-notification-sent', {
            status: true,
            targetUserId
        });
    }

    return true;
}
app.post('/api/fcm-send-logout', async (req, res) => {
    const { user_id, activeid, token } = req.body;
    try {
        if (user_id) {
            const userTokens = await db('fcmtoken').where('user_id', user_id);

            if (userTokens?.length > 0) {
                // Filter out the token from request body
                const tokensToSend = userTokens.filter(t => t.token && t.token !== token);

                if (tokensToSend.length > 0) {
                    const messages = tokensToSend.map(t => ({
                        token: t.token,
                        data: { ACTION: "LOGOUT" }
                    }));
                    await sendPushNotificationMessage(messages);
                }

                // ✅ Only update if token is not empty
                if (token && token.trim() !== "") {
                    await db('fcmtoken').where('user_id', user_id).update({ token });
                    await db('profile').where('user_id', user_id).update({ token });
                }
            } else {
                // If no tokens found, insert if valid
                if (token && token.trim() !== "") {
                    const exists = await db('fcmtoken')
                        .where({ user_id, token })
                        .first();
                    if (!exists) {
                        await db('fcmtoken').insert({ user_id, token });
                    }
                }
            }
        }

        return res.status(200).json({ status: true, message: 'success' });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ status: false, message: 'Internal server error' });
    }
});



app.post('/fcm-send-logout', async (req, res) => {
    const { user_id, activeid, token } = req.body;
    try {
        if (user_id) {
            const userTokens = await db('fcmtoken').where('user_id', user_id);

            if (userTokens?.length > 0) {
                // Filter out the token from request body
                const tokensToSend = userTokens.filter(t => t.token && t.token !== token);

                if (tokensToSend.length > 0) {
                    const messages = tokensToSend.map(t => ({
                        token: t.token,
                        data: { ACTION: "LOGOUT" }
                    }));
                    await sendPushNotificationMessage(messages);
                }

                // ✅ Only update if token is not empty
                if (token && token.trim() !== "") {
                    await db('fcmtoken').where('user_id', user_id).update({ token });
                    await db('profile').where('user_id', user_id).update({ token });
                }
            } else {
                // If no tokens found, insert if valid
                if (token && token.trim() !== "") {
                    const exists = await db('fcmtoken')
                        .where({ user_id, token })
                        .first();
                    if (!exists) {
                        await db('fcmtoken').insert({ user_id, token });
                    }
                }
            }
        }

        return res.status(200).json({ status: true, message: 'success' });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ status: false, message: 'Internal server error' });
    }
});


async function sendMessages(messages) {
    try {
        io.emit('notification-success', {
            error: messages,
        });
        const responses = await Promise.all(messages.map(message => admin.messaging().send(message)));
        console.log('FCM Responses:', responses);
    } catch (error) {

        console.error('Error sending FCM messages:', error);
    }
}
async function sendMessages1(messages) {
    for (const message of messages) {
        try {
            io.emit('notification-success', {
                error: message,
            });

            await admin.messaging().send(message)
                .then(response => console.log("Successfully sent:", response))
                .catch(error => {
                    console.error("FCM Error:", error.code, error.message);
                    io.emit('notification-unsuccess', { error: error.message });
                });

        } catch (error) {

            io.emit('notification-unsuccess', {
                error: error,
            });

            console.error('Error sending FCM message:', error);
        }
    }
}
app.use('/api/', roomsRouter);
app.use('/api/', imagesRouter);
app.use('/api/', VideosRouter);
app.use('/api/images/', ImageArray);



const SCOPES = ["https://www.googleapis.com/auth/firebase.messaging"];

async function getAccessToken() {
    const auth = new GoogleAuth({
        credentials: serviceAccount,
        scopes: SCOPES,
    });

    const client = await auth.getClient();
    const accessToken = await client.getAccessToken();
    return accessToken.token;
}

async function sendPushNotificationMessage(messageObject) {
    try {
        const accessToken = await getAccessToken();
        const projectId = serviceAccount.project_id;

        let lastResponseData = null;

        for (const element of messageObject) {
            const message = {
                message: {
                    token: element.token,
                    data: element.data,
                },
            };

            const url = `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`;

            try {
                const response = await axios.post(url, message, {
                    headers: {
                        Authorization: `Bearer ${accessToken}`,
                        "Content-Type": "application/json",
                    },
                });

                console.log(element, "KKSKKSKS");
                lastResponseData = response.data;
            } catch (error) {
                console.error(`Error sending message to token ${element.token}:`, error.response?.data || error.message);
            }
        }

        return lastResponseData;
    } catch (error) {
        console.error("Unexpected error in sendPushNotificationMessage:", error.message);
        throw error; // Optional: rethrow if you want the calling function to handle it
    }
}


const port = process.env.PORT || 3000;
// const localIP = '127.0.0.1';

server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
