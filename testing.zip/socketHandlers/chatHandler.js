const axios = require('axios');
const path = require('path');
const fs = require('fs');
const FormData = require('form-data');

const ROLE_ENUM = {
    PATIENT: 'patient',
    DOCTOR: 'doctor',
    STAFF: 'staff',
    VHM: 'vhm',
};

const ROLE_LABELS = {
    [ROLE_ENUM.PATIENT]: 'patient',
    [ROLE_ENUM.DOCTOR]: 'doctor',
    [ROLE_ENUM.STAFF]: 'staff',
    [ROLE_ENUM.VHM]: 'vhm',
};

const MESSAGE_TYPE = {
    TEXT: 'TextMessage',
    IMAGE: 'ImageMessage',
    PDF: 'PDFDocument',
    AUDIO: 'AudioMessage',
    VIDEO: 'VideoMessage',
};

const ATTACHMENT_TYPES = [MESSAGE_TYPE.IMAGE, MESSAGE_TYPE.PDF, MESSAGE_TYPE.AUDIO, MESSAGE_TYPE.VIDEO];

const PROXY_ROLES = [ROLE_ENUM.VHM, ROLE_ENUM.STAFF, ROLE_ENUM.DOCTOR];
const NON_PATIENT_ROLES = [ROLE_ENUM.VHM, ROLE_ENUM.STAFF, ROLE_ENUM.DOCTOR];

function getRoleLabel(role) {
    return ROLE_LABELS[role] || role || '';
}

function buildNotificationTitle(senderRole, senderName) {
    const label = getRoleLabel(senderRole);
    if (senderRole === ROLE_ENUM.DOCTOR) {
        return `Dr. ${senderName}`;
    }
    return `${label} ${senderName}`.trim();
}

function buildNotificationBody(senderRole, senderName, message) {
    const title = buildNotificationTitle(senderRole, senderName);
    const preview = message && message.length > 50 ? message.substring(0, 50) + '...' : message;
    return `${title}: ${preview}`;
}

function getAttachmentFileType(messageType) {
    switch (messageType) {
        case MESSAGE_TYPE.IMAGE: return 'images';
        case MESSAGE_TYPE.VIDEO: return 'videos';
        case MESSAGE_TYPE.AUDIO: return 'audio';
        case MESSAGE_TYPE.PDF: return 'documents';
        default: return 'other';
    }
}

function getAttachmentMimeType(messageType) {
    switch (messageType) {
        case MESSAGE_TYPE.IMAGE: return 'image';
        case MESSAGE_TYPE.VIDEO: return 'video';
        case MESSAGE_TYPE.AUDIO: return 'audio';
        case MESSAGE_TYPE.PDF: return 'application/pdf';
        default: return 'application/octet-stream';
    }
}

async function uploadFileToServer(filePath, from, messageType, baseUrl) {
    const fileType = getAttachmentFileType(messageType);
    const fileName = path.basename(filePath);
    const form = new FormData();
    form.append('file', fs.createReadStream(filePath), {
        filename: fileName,
        contentType: getAttachmentMimeType(messageType),
    });

    const uploadUrl = `${baseUrl}/api/upload-single`;
    const response = await axios.post(uploadUrl, form, {
        headers: {
            ...form.getHeaders(),
        },
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
    });

    return response.data;
}

function validateChatRules({ senderRole, receiverRole, chat_mode, patient_id, from_id }) {
    const errors = [];

    const isProxyChat = NON_PATIENT_ROLES.includes(senderRole) && NON_PATIENT_ROLES.includes(receiverRole);

    const isDirectToPatient = NON_PATIENT_ROLES.includes(senderRole) && receiverRole === ROLE_ENUM.PATIENT;

    const isPatientDirect = senderRole === ROLE_ENUM.PATIENT && NON_PATIENT_ROLES.includes(receiverRole);

    const isDoctorPatientChat = (senderRole === ROLE_ENUM.DOCTOR && receiverRole === ROLE_ENUM.PATIENT) ||
                                (senderRole === ROLE_ENUM.PATIENT && receiverRole === ROLE_ENUM.DOCTOR);

   

    if (isDirectToPatient) {
        if (senderRole === ROLE_ENUM.VHM || senderRole === ROLE_ENUM.STAFF) {
            if (chat_mode && chat_mode !== messageType) {
                errors.push(`${senderRole} → patient messaging only supports ${messageType} mode, not general`);
            }
        }
    }

    if (isPatientDirect) {
        if (receiverRole === ROLE_ENUM.VHM || receiverRole === ROLE_ENUM.STAFF) {
            if (chat_mode && chat_mode !== messageType) {
                errors.push(`patient → ${receiverRole} messaging only supports ${messageType} mode, not general`);
            }
        }
    }

    if (chat_mode === 'general' && !isDoctorPatientChat) {
        errors.push('General chat mode is only available for doctor ↔ patient messaging');
    }

    return {
        valid: errors.length === 0,
        errors: errors,
    };
}

function registerChatHandlers(io, socket, db, sendPushNotificationMessage, baseUrl) {

    socket.on('send-message', async (data, ackCallback) => {
        try {
            let {
                from, to, message, messageType, attachment, iscaregiver,
                metadata, metaData, patientId, doctorId,
                patientUserName, patientUserProfile,
                doctorUserName, doctorUserProfile,
                chat_mode,
                senderRole: senderRoleFromFrontend, receiverRole: receiverRoleFromFrontend,
                fromUserRole, toUserRole,
                fromUserName, fromUserProfile, toUserName, toUserProfile,
                filePath,
            } = data;

            if (!senderRoleFromFrontend && fromUserRole) senderRoleFromFrontend = fromUserRole;
            if (!receiverRoleFromFrontend && toUserRole) receiverRoleFromFrontend = toUserRole;

            if (!messageType) messageType = MESSAGE_TYPE.TEXT;
            if (!chat_mode) chat_mode = messageType;

            if (!from && from !== 0) {
                const errorMsg = 'From user ID is required';
                socket.emit('notification-error', { status: false, message: errorMsg });
                if (ackCallback) ackCallback({ status: false, error: errorMsg });
                return;
            }
            if (!to && to !== 0) {
                const errorMsg = 'To user ID is required';
                socket.emit('notification-error', { status: false, message: errorMsg });
                if (ackCallback) ackCallback({ status: false, error: errorMsg });
                return;
            }

            from = parseInt(from) || from;
            to = parseInt(to) || to;

            const localDate = new Date();
            const utcDateString = localDate.toISOString();

            const queries = [
                db('profile').where('user_id', from).first(),
                db('profile').where('user_id', to).first(),
            ];

            if (patientId) {
                queries.push(db('profile').where('user_id', parseInt(patientId)).first());
            }
            if (doctorId) {
                queries.push(db('profile').where('user_id', parseInt(doctorId)).first());
            }

            const results = await Promise.all(queries);
            const fromU = results[0];
            const toU = results[1];
            let resultIndex = 2;
            const patientData = patientId ? results[resultIndex++] : null;
            const doctorData = doctorId ? results[resultIndex++] : null;

            if (!fromU || !toU) {
                const errorMsg = !fromU ? 'From User not found' : 'To User not found';
                socket.emit('notification-error', { status: false, message: errorMsg });
                if (ackCallback) ackCallback({ status: false, error: errorMsg });
                return;
            }

            const senderRole = senderRoleFromFrontend || fromU.role || '';
            const receiverRole = receiverRoleFromFrontend || toU.role || '';
            const chatType = `${senderRole}-${receiverRole}`;

            const validation = validateChatRules({
                senderRole,
                receiverRole,
                chat_mode,
                patientId,
                from_id: from,
            });

            if (!validation.valid) {
                const errorMsg = validation.errors.join('; ');
                console.log(`[chat-validation] FAILED: ${chatType} | ${errorMsg}`);
                socket.emit('notification-error', { status: false, message: errorMsg });
                if (ackCallback) ackCallback({ status: false, error: errorMsg });
                return;
            }

            let chatAttachment = null;
            let chatMessage = message || '';
            const chatMetaData = metaData || metadata || {};

            if (ATTACHMENT_TYPES.includes(messageType)) {
                if (attachment && Array.isArray(attachment)) {
                    chatAttachment = attachment;
                } else if (attachment && typeof attachment === 'string') {
                    chatAttachment = [attachment];
                } else {
                    chatAttachment = [];
                }
            }

            const chatNew = {
                from_id: from,
                to_id: to,
                patientId: patientId || null,
                doctorId: doctorId || null,
                message: chatMessage,
                created_time: utcDateString,
                attachment: chatAttachment ? JSON.stringify(chatAttachment) : null,
                messageType: messageType || MESSAGE_TYPE.TEXT,
                type: messageType || MESSAGE_TYPE.TEXT,
                is_read: '1',
                is_chat: '1',
                metadata: chatMetaData ? JSON.stringify(chatMetaData) : null,
                senderRole: senderRole || null,
                receiverRole: receiverRole || null,
                chat_mode: chat_mode || null,
            };

            const [insertedId] = await db('chat').insert(chatNew);
            const id = insertedId;

            const fromUserObj = {
                id: fromU.user_id,
                first_name: fromU.first_name,
                last_name: fromU.last_name,
                image: fromUserProfile || fromU.image || '',
                role: fromU.role || '',
            };

            const toUserObj = {
                id: toU.user_id,
                first_name: toU.first_name,
                last_name: toU.last_name,
                image: toUserProfile || toU.image || '',
                role: toU.role || '',
            };

            const patientObj = patientData ? {
                id: patientData.user_id,
                first_name: patientUserName || patientData.first_name,
                last_name: patientData.last_name,
                image: patientUserProfile || patientData.image || '',
                email: patientData.email || '',
                role: patientData.role || '',
            } : null;

            const doctorObj = doctorData ? {
                id: doctorData.user_id,
                first_name: doctorUserName || doctorData.first_name,
                last_name: doctorData.last_name,
                image: doctorUserProfile || doctorData.image || '',
                email: doctorData.email || '',
                role: doctorData.role || '',
            } : null;

            if (ackCallback) {
                ackCallback({
                    status: true,
                    msgId: id,
                    chatType: chatType,
                    chat_mode: chat_mode || chatType,
                });
            }

            const senderFullName = fromUserName || `${fromU.first_name || ''} ${fromU.last_name || ''}`.trim();
            const notificationTitle = buildNotificationTitle(senderRole, senderFullName);
            const notificationBody = buildNotificationBody(senderRole, senderFullName, chatMessage);

            const responseData = {
                ACTION: 'MESSAGE',
                fromUser: JSON.stringify(fromUserObj),
                toUser: JSON.stringify(toUserObj),
                patient: patientObj ? JSON.stringify(patientObj) : null,
                doctor: doctorObj ? JSON.stringify(doctorObj) : null,
                message: chatMessage,
                messageType: messageType || MESSAGE_TYPE.TEXT,
                attachment: JSON.stringify(chatAttachment || []),
                metaData: JSON.stringify(chatMetaData),
                insertedMessage: String(id),
                chatType: chatType,
                patientId:patientId || null,
                doctorId: doctorId || null,
                senderRole: senderRole,
                receiverRole: receiverRole,
                chat_mode: chat_mode || chatType,
                title: notificationTitle,
                body: notificationBody,
                created_time: utcDateString,
            };

            const userTokens = await db('fcmtoken').where('user_id', to).select('token');
            const tokenList = userTokens.map(t => t.token).filter(t => t);

            if (tokenList.length > 0) {
                const fcmMessages = tokenList.map(token => ({
                    token,
                    data: {
                        DocotorName: JSON.stringify(notificationTitle),
                        fromUser: JSON.stringify(fromUserObj),
                        toUser: JSON.stringify(toUserObj),
                        patient: patientObj ? JSON.stringify(patientObj) : null,
                        doctor: doctorObj ? JSON.stringify(doctorObj) : null,
                        ACTION: JSON.stringify('MESSAGE'),
                        insertedMessage: String(id),
                        messageType: JSON.stringify(messageType || MESSAGE_TYPE.TEXT),
                        attachment: JSON.stringify(chatAttachment || []),
                        message: JSON.stringify(chatMessage),
                        metaData: JSON.stringify(chatMetaData),
                        senderRole: JSON.stringify(senderRole),
                        receiverRole: JSON.stringify(receiverRole),
                        chatType: chatType,
                        chat_mode: chat_mode || chatType,
                        title: JSON.stringify(notificationTitle),
                        body: JSON.stringify(notificationBody),
                    },
                    notification: {
                        title: notificationTitle,
                        body: notificationBody,
                    },
                }));

                await sendPushNotificationMessage(fcmMessages);
            }

            io.emit('notification-success', responseData);
            io.emit(`receive-message-${to}`, responseData);
            io.emit('pushnotification',  responseData );

            console.log(`[role-message] ${chatType} | ${senderRole}(${from}) -> ${receiverRole}(${to}) | msgId: ${id} | type: ${messageType} | patient: ${patientId || 'none'} | mode: ${chat_mode}`);

        } catch (error) {
            console.error('[role-message] Error:', error);
            socket.emit('notification-error', { status: false, message: 'Error processing role-message' });
            if (ackCallback) ackCallback({ status: false, error: error.message });
        }
    });

    socket.on('upload-and-send', async (data, ackCallback) => {
        try {
            let {
                from, to, messageType, filePath,
                iscaregiver, metadata, metaData, patientId, doctorId,
                chat_mode,
                senderRole: senderRoleFromFrontend, receiverRole: receiverRoleFromFrontend,
                fromUserRole, toUserRole,
                fromUserName, fromUserProfile, toUserName, toUserProfile,
            } = data;

            if (!senderRoleFromFrontend && fromUserRole) senderRoleFromFrontend = fromUserRole;
            if (!receiverRoleFromFrontend && toUserRole) receiverRoleFromFrontend = toUserRole;

            if (!filePath) {
                const errorMsg = 'filePath is required for upload-and-send';
                socket.emit('notification-error', { status: false, message: errorMsg });
                if (ackCallback) ackCallback({ status: false, error: errorMsg });
                return;
            }

            if (!ATTACHMENT_TYPES.includes(messageType)) {
                const errorMsg = `Invalid messageType for upload: ${messageType}. Use: ${ATTACHMENT_TYPES.join(', ')}`;
                socket.emit('notification-error', { status: false, message: errorMsg });
                if (ackCallback) ackCallback({ status: false, error: errorMsg });
                return;
            }

            from = parseInt(from) || from;
            to = parseInt(to) || to;

            let uploadedUrl = null;
            try {
                const uploadResult = await uploadFileToServer(filePath, from, messageType, baseUrl || `http://localhost:${process.env.PORT || 3001}`);
                uploadedUrl = uploadResult.url || uploadResult.data?.url || null;
            } catch (uploadErr) {
                console.error('[upload-and-send] Upload failed:', uploadErr.message);
                socket.emit('notification-error', { status: false, message: 'File upload failed' });
                if (ackCallback) ackCallback({ status: false, error: 'File upload failed' });
                return;
            }

            let chatMessage = '';
            if (messageType === MESSAGE_TYPE.PDF) {
                chatMessage = path.basename(filePath);
            }

            socket.emit('send-message', {
                from,
                to,
                message: chatMessage,
                messageType,
                attachment: uploadedUrl ? [uploadedUrl] : [],
                iscaregiver: iscaregiver || '',
                metadata: metadata || null,
                metaData: metaData || null,
                patientId: patientId || null,
                doctorId: doctorId || null,
                chat_mode: chat_mode || chatType,
                senderRole: senderRoleFromFrontend,
                receiverRole: receiverRoleFromFrontend,
                fromUserName,
                fromUserProfile,
                toUserName,
                toUserProfile,
            }, ackCallback);

        } catch (error) {
            console.error('[upload-and-send] Error:', error);
            socket.emit('notification-error', { status: false, message: 'Error in upload-and-send' });
            if (ackCallback) ackCallback({ status: false, error: error.message });
        }
    });

    socket.on('validate-chat', async (data, ackCallback) => {
        try {
            const { senderRole, receiverRole, chat_mode,  patient_id, from_id } = data;

            const validation = validateChatRules({
                senderRole,
                receiverRole,
                chat_mode,
                patient_id,
                from_id,
            });

            if (ackCallback) {
                ackCallback({
                    valid: validation.valid,
                    errors: validation.errors,
                    chatType: `${senderRole}-${receiverRole}`,
                });
            }

        } catch (error) {
            console.error('[validate-chat] Error:', error);
            if (ackCallback) ackCallback({ valid: false, errors: [error.message] });
        }
    });
}

module.exports = {
    ROLE_ENUM,
    ROLE_LABELS,
    MESSAGE_TYPE,
    ATTACHMENT_TYPES,
    getRoleLabel,
    buildNotificationTitle,
    buildNotificationBody,
    registerChatHandlers,
    validateChatRules,
};
