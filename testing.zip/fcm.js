const { GoogleAuth } = require("google-auth-library");
const axios = require('axios');
const db = require('./db');
const serviceAccount = require('./public/serviceAccountKey.json');

const SCOPES = ["https://www.googleapis.com/auth/firebase.messaging"];

async function getAccessToken() {
    const auth = new GoogleAuth({
        credentials: serviceAccount,
        scopes: SCOPES,
    });

    const client = await auth.getClient();
    const accessToken = await client.getAccessToken();
    return accessToken.token;
}

async function sendPushNotificationMessage(messageObject) {
    try {
        const accessToken = await getAccessToken();
        const projectId = serviceAccount.project_id;

        let lastResponseData = null;

        for (const element of messageObject) {
            let token = element.token;
            if (token && typeof token === 'string' && token.includes('%')) {
                try {
                    token = decodeURIComponent(token);
                } catch (e) {
                    console.error("Failed to decode token in sendPushNotificationMessage:", token);
                }
            }

            const message = {
                message: {
                    token: token,
                    data: element.data,
                },
            };

            if (element.notification) {
                message.message.notification = element.notification;
            }

            const url = `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`;

            try {
                const response = await axios.post(url, message, {
                    headers: {
                        Authorization: `Bearer ${accessToken}`,
                        "Content-Type": "application/json",
                    },
                });

                console.log("FCM Sent Success:", element.token);
                lastResponseData = response.data;
            } catch (error) {
                const errorData = error.response?.data?.error;
                // Auto-delete invalid tokens from database
                if (errorData?.message === 'NotRegistered' || errorData?.status === 'INVALID_ARGUMENT' || errorData?.status === 'NOT_FOUND') {
                    console.log(`Pruning invalid token: ${element.token}`);
                    await db('fcmtoken').where({ token: element.token }).delete();
                }
                console.error(`Error sending message to token ${element.token}:`, error.response?.data || error.message);
            }
        }

        return lastResponseData;
    } catch (error) {
        console.error("Unexpected error in sendPushNotificationMessage:", error.message);
        throw error;
    }
}

module.exports = {
    sendPushNotificationMessage,
    getAccessToken
};
